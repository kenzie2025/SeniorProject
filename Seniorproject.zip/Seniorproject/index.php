<?php
// index.php - Home Page
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Welcome to My Website</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <!-- Navbar Section -->
    <header>
        <nav class="navbar">
            <div class="logo">
                <h2>BrokenoMore</h2>
            </div>
            <ul class="nav-links">
                <li><a href="index.php">Home🏠</a></li>
                <li><a href="login.php">Login✨</a></li>
                <li><a href="signup.php">Sign Up🚀</a></li>
                <li><a href="about.php">Aboutℹ️</a></li>
                <li><a href="contact.php">Contact✉️</a></li>
                <li><a href="tips.php">Tips📋</a></li>
            </ul>
        </nav>
    </header>

    <!-- Hero Section -->
    <section class="hero">
        <div class="hero-content">
            <h1>Welcome to the Future of Budgeting</h1>
            <p>Your personal budgeting assistant to help manage your finances!</p>
            <a href="signup.php" class="cta-btn">Get Started</a>
        </div>
    </section> 

    <!-- Features Section -->
    <section class="features">
        <div class="feature">
            <h3>Easy to Use</h3>
            <p>Track your spending with just a few clicks.</p>
        </div>
        <div class="feature">
            <h3>Secure</h3>
            <p>We keep your data safe and encrypted.</p>
        </div>
        <div class="feature">
            <h3>Fast Insights</h3>
            <p>Get real-time updates and budgeting tips.</p>
        </div>
    </section>
<!-- Testimonials Section -->
<section class="testimonials">
    <h2>What Students Are Saying</h2>
    <div class="testimonial-list">
        <div class="testimonial">
            <img src="https://randomuser.me/api/portraits/men/45.jpg" alt="Jordan" class="testimonial-img">
            <p>"This app made budgeting easy and actually fun! I saved over $500 in 2 months."</p>
            <h4>- Jordan M., College Sophomore</h4>
        </div>
        <div class="testimonial">
            <img src="https://randomuser.me/api/portraits/women/44.jpg" alt="Alexis" class="testimonial-img">
            <p>"I finally understand where my money is going. Highly recommend for any student!"</p>
            <h4>- Alexis T., First-Year Student</h4>
        </div>
        <div class="testimonial">
           <img src="https://randomuser.me/api/portraits/men/52.jpg" alt="Chris" class="testimonial-img">
            <p>"Simple, clean, and powerful. It keeps me on track without overwhelming me."</p>
            <h4>- Chris R. College Senior</h4>
        </div>
    </div>
</section>


    <!-- Footer Section -->
    <footer>
        <p>&copy; 2025 BrokenoMore. All Rights Reserved.</p>
    </footer>

</body>
</html>

