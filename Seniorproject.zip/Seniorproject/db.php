<?php
// db.php - Database connection file

$servername = "localhost";
$username = "root"; // Default username for XAMPP MySQL
$password = "";     // Default password for XAMPP MySQL
$dbname = "student_budget"; // The database name we created

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
