<?php
session_start();

// Make sure the user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// Connect to database
include('db.php');

// Check if an ID is provided
if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $userId = $_SESSION['user_id'];

    // Delete the entry but make sure it belongs to the logged-in user
    $sql = "DELETE FROM budget_entries WHERE id = ? AND user_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $id, $userId);

    if ($stmt->execute()) {
        header('Location: budget.php?message=deleted');
        exit();
    } else {
        echo "Error deleting entry.";
    }
} else {
    echo "Invalid request.";
}
?>
