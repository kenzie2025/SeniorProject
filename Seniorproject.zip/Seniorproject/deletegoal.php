<?php
session_start();
include('db.php');

if (!isset($_SESSION['user_id']) || !isset($_GET['id'])) {
    header('Location: login.php');
    exit();
}

$goalId = intval($_GET['id']);
$userId = $_SESSION['user_id'];

// Delete only if the goal belongs to the user
$stmt = $conn->prepare("DELETE FROM savings_goals WHERE id = ? AND user_id = ?");
$stmt->bind_param("ii", $goalId, $userId);
$stmt->execute();
$stmt->close();

header("Location: budget.php?goal_deleted=1");
exit();
?>
