<?php
session_start();
session_destroy();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Logged Out</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<section class="hero">
        <h1>Thanks for visiting!</h1>
        <p>See you next time</p>
        </section>

<div class="form-container">
    <h2>Logged Out Successfully</h2>
    <a href="login.php" class="btn">Login Again</a>
</div>

</body>
</html>
