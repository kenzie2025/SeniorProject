<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = htmlspecialchars($_POST['name']);
    $email = htmlspecialchars($_POST['email']);
    $message = htmlspecialchars($_POST['message']);
    
    // Here, you can save the data or send it via email
    // For example, you can echo it out to confirm receipt:
    echo "Thank you for contacting us, $name! We'll get back to you soon.";
}
?>

