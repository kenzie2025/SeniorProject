<?php
session_start();
include('db.php');

if (!isset($_SESSION['user_id']) || !isset($_GET['id'])) {
    header('Location: login.php');
    exit();
}

$userId = $_SESSION['user_id'];
$goalId = intval($_GET['id']);

// Fetch the goal
$stmt = $conn->prepare("SELECT * FROM savings_goals WHERE id = ? AND user_id = ?");
$stmt->bind_param("ii", $goalId, $userId);
$stmt->execute();
$result = $stmt->get_result();
$goal = $result->fetch_assoc();

if (!$goal) {
    echo "Goal not found.";
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = trim($_POST['title']);
    $goalAmount = floatval($_POST['goal_amount']);

    $update = $conn->prepare("UPDATE savings_goals SET title = ?, goal_amount = ? WHERE id = ? AND user_id = ?");
    $update->bind_param("sdii", $title, $goalAmount, $goalId, $userId);
    $update->execute();
    $update->close();

    header("Location: budget.php?goal_updated=1");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Savings Goal</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <section class="form-container">
        <h2>Edit Goal: <?= htmlspecialchars($goal['title']) ?></h2>
        <form method="POST">
            <div class="input-group">
                <label for="title">Title</label>
                <input type="text" name="title" id="title" value="<?= htmlspecialchars($goal['title']) ?>" required>
            </div>

            <div class="input-group">
                <label for="goal_amount">Goal Amount ($)</label>
                <input type="number" step="0.01" name="goal_amount" id="goal_amount" value="<?= $goal['goal_amount'] ?>" required>
            </div>

            <button type="submit" class="btn">Update Goal</button>
        </form>
    </section>
</body>
</html>
