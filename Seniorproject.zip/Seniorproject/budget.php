<?php
// budget.php - Budget tracker page
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// Include the database connection
include('db.php');

// Fetch all savings goals for this user
$userId = $_SESSION['user_id'];
$goalQuery = "SELECT * FROM savings_goals WHERE user_id = $userId";
$goalResult = $conn->query($goalQuery);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Budget Tracker</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<nav class="navbar">
  <ul>
    <li><a href="index.php">🏠 Home</a></li>
    <li><a href="budget.php">💰 Budget Tracker</a></li>
    <li><a href="tips.php">📋 Saving Tips</a></li>
    <li><a href="logout.php">🚪 Logout</a></li>
  </ul>
</nav>
    <!-- Hero Section -->
    <section class="hero">
        <div class="hero-content"></div>
    </section>

    <h2>Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?></h2>
    <p>Track your budget here!</p>

    <!-- Savings Goals with Progress Bars -->
    <section class="form-container">
        <h2>Your Savings Goals</h2>
        <?php
        if ($goalResult->num_rows > 0) {
            while ($goal = $goalResult->fetch_assoc()) {
                $goalTitle = $goal['title'];
                $goalAmount = $goal['goal_amount'];

                // Match savings entries by description
                $savedQuery = "SELECT SUM(amount) as saved FROM budget_entries 
                               WHERE user_id = ? AND type = 'savings' AND description = ?";
                $stmt = $conn->prepare($savedQuery);
                $stmt->bind_param("is", $userId, $goalTitle);
                $stmt->execute();
                $savedResult = $stmt->get_result();
                $row = $savedResult->fetch_assoc();
                $current = $row['saved'] ?? 0;
                $progress = min(100, ($goalAmount > 0 ? ($current / $goalAmount) * 100 : 0));
        ?>
            <div style="margin-bottom: 20px;">
    <strong><?= htmlspecialchars($goalTitle) ?></strong>
    <p>Saved: $<?= number_format($current, 2) ?> of $<?= number_format($goalAmount, 2) ?> (<?= round($progress) ?>%)</p>
    <div class="progress-bar-container">
        <div class="progress-bar-fill" style="width: <?= $progress ?>%;"></div>
    </div>
    <div style="margin-top: 10px;">
        <a class="btn" href="editgoal.php?id=<?= $goal['id'] ?>">Edit</a>
        <a class="btn" style="background-color: red;" 
           href="deletegoal.php?id=<?= $goal['id'] ?>" 
           onclick="return confirm('Are you sure you want to delete this goal?');">Delete</a>
    </div>
</div>
        <?php
            }
        } else {
            echo "<p>You haven't set any goals yet.</p>";
        }
        ?>
    </section>
<!-- Add a New Savings Goal -->
<section class="form-container">
    <h2>Add a New Savings Goal</h2>
    <form action="addgoal.php" method="POST">
        <div class="input-group">
            <label for="title">Goal Title</label>
            <input type="text" name="title" id="title" required>
        </div>

        <div class="input-group">
            <label for="goal_amount">Target Amount ($)</label>
            <input type="number" step="0.01" name="goal_amount" id="goal_amount" required>
        </div>

        <button type="submit" class="btn">Add Goal</button>
    </form>
</section>

    <!-- Budget Entry Form -->
    <section class="form-container">
        <h2>Add a New Budget Entry</h2>
        <form action="addbudget.php" method="POST">
            <div class="input-group">
                <label for="amount">Amount ($)</label>
                <input type="number" step="0.01" name="amount" id="amount" required>
            </div>

            <div class="input-group">
                <label for="type">Type</label>
                <select name="type" id="type" required>
                    <option value="income">Income</option>
                    <option value="savings">Savings</option>
                    <option value="expense">Expense</option>
                </select>
            </div>

            <div class="input-group">
                <label for="description">Description</label>
                <input type="text" name="description" id="description" required>
            </div>

            <button type="submit" class="btn">Add Entry</button>
        </form>
    </section>

    <!-- Budget History Table -->
    <section class="form-container">
        <h2>Your Budget History</h2>
        <table>
            <thead>
                <tr>
                    <th>Amount ($)</th>
                    <th>Type</th>
                    <th>Description</th>
                    <th>Date</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $sql = "SELECT * FROM budget_entries WHERE user_id = $userId ORDER BY created_at DESC";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>$" . number_format($row['amount'], 2) . "</td>";
                        echo "<td>" . ucfirst($row['type']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['description']) . "</td>";
                        echo "<td>" . $row['created_at'] . "</td>";
                        echo "<td><a class='btn' style='background-color:red;' href='deletebutton.php?id=" . $row['id'] . "' onclick='return confirm(\"Are you sure you want to delete this entry?\");'>Delete</a></td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='5'>No entries yet.</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </section>

</body>
</html>
