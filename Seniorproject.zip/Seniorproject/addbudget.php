<?php
// add_budget.php - Handles adding a budget entry

session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// Include the database connection
include('db.php');

// Check if the form was submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get and sanitize the form inputs
    $amount = floatval($_POST['amount']);
    $type = htmlspecialchars($_POST['type']);
    $description = htmlspecialchars($_POST['description']);
    $userId = $_SESSION['user_id'];

    // Simple validation
    if ($amount > 0 && !empty($type) && !empty($description)) {
        // Insert into the database
        $stmt = $conn->prepare("INSERT INTO budget_entries (user_id, amount, type, description, created_at) VALUES (?, ?, ?, ?, NOW())");
        $stmt->bind_param("idss", $userId, $amount, $type, $description);

        if ($stmt->execute()) {
            // Success! Redirect back to budget.php
            header('Location: budget.php');
            exit();
        } else {
            echo "Error: " . $stmt->error;
        }

        $stmt->close();
    } else {
        echo "Please fill in all fields correctly.";
    }
} else {
    // If accessed directly without POST, redirect
    header('Location: budget.php');
    exit();
}
?>
