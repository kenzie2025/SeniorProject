<?php
// tips.php - Saving Tips Page

session_start();

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Saving Tips</title>
  <style>
    .tips-container {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
      gap: 20px;
      padding: 20px;
      max-width: 1200px;
      margin: 0 auto;
    }

    .tip-card {
      background-color: #f0fff0;
      border: 1px solid #cce5cc;
      border-radius: 12px;
      box-shadow: 2px 2px 6px rgba(0,0,0,0.1);
      padding: 20px;
      transition: transform 0.2s ease-in-out;
    }

    .tip-card:hover {
      transform: scale(1.03);
      box-shadow: 3px 3px 10px rgba(0, 100, 0, 0.15);
    }

    .tip-card h3 {
      margin-top: 0;
      font-size: 1.2em;
      color: #2e8b57;
    }

    .hero {
      background: linear-gradient(to right, #a8e063, #56ab2f);
      color: white;
      text-align: center;
      padding: 40px 20px;
    }

    .cta-btn {
      display: inline-block;
      margin-top: 15px;
      padding: 10px 20px;
      background-color: #006400;
      color: white;
      text-decoration: none;
      border-radius: 6px;
    }

    header {
      text-align: center;
      margin-top: 20px;
    }

    header a {
      margin: 0 10px;
    }
  </style>
</head>

<body>
  <!-- Hero Section -->
  <section class="hero">
    <div class="hero-content">
      <h1>Welcome to the Future of Budgeting</h1>
      <p>Your personal budgeting assistant to help manage your finances!</p>
      <a href="signup.php" class="cta-btn">Get Started</a>
    </div>
  </section>

  <header>
    <h1>Saving Tips for College Students</h1>
    <p>Welcome, <?php echo $_SESSION['username']; ?>! Here are some tips to help you save money while in college.</p>
    <p><a href="index.php">Back to Homepage</a> | <a href="budget.php">Go to Budget Tracker</a> | <a href="logout.php">Logout</a></p>
  </header>

  <div class="tips-container">
    <div class="tip-card">
      <h3>🎓 Use Student Discounts</h3>
      <p>Many businesses offer student discounts. Always ask if one is available!</p>
    </div>
    <div class="tip-card">
      <h3>🍽️ Meal Prep & Cook at Home</h3>
      <p>Cooking your own meals can save you a lot compared to eating out regularly.</p>
    </div>
    <div class="tip-card">
      <h3>📚 Buy Used Textbooks</h3>
      <p>Save money on textbooks by buying used or renting them instead of purchasing new ones.</p>
    </div>
    <div class="tip-card">
      <h3>📊 Set a Budget</h3>
      <p>Track your income and expenses to ensure you're saving money each month. Use this website’s budget tracker!</p>
    </div>
    <div class="tip-card">
      <h3>🎉 Look for Free Events</h3>
      <p>Take advantage of free campus events, activities, and entertainment. You don’t always have to spend money to have fun!</p>
    </div>
    <div class="tip-card">
      <h3>📉 Cut Down on Subscriptions</h3>
      <p>Evaluate your monthly subscriptions like Netflix or Spotify. Share plans or downgrade to cheaper versions.</p>
    </div>
    <div class="tip-card">
      <h3>🚌 Use Public Transportation</h3>
      <p>Save on gas and parking by taking public transportation or using bike-sharing programs on campus.</p>
    </div>
  </div>

</body>
</html>

