
<?php
// signup.php - Signup page

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Include the database connection file
    include('db.php');

    // Get the form data
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    $password_hashed = password_hash($password, PASSWORD_DEFAULT); // Hash password

    // Insert the user into the database
    $sql = "INSERT INTO users (username, email, password) VALUES ('$username', '$email', '$password_hashed')";

    if ($conn->query($sql) === TRUE) {
        echo "New account created successfully. <a href='login.php'>Login here</a>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Signup</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        h2 {
            text-align: center;
        }
    </style>
</head>
<body>
    <!-- Hero section copied directly -->
    <section class="hero">
        <h1>Welcome!</h1>
        <p>Start your journey today</p>
        <a href="register.php" class="cta-btn">Get Started</a>
    </section>

    <!-- Centered Signup Heading -->
    <h2>Signup</h2>

    <form method="POST" action="signup.php">
        <label for="username">Username:</label>
        <input type="text" name="username" id="username" required><br>

        <label for="email">Email:</label>
        <input type="email" name="email" id="email" required><br>

        <label for="password">Password:</label>
        <input type="password" name="password" id="password" required><br>

        <button type="submit">Sign Up</button>
    </form>
    <p>Already have an account? <a href="login.php">Login here</a></p>
</body>
</html>