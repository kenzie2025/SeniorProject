<?php
session_start();

// Optional: Protect the page
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>About Us</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      line-height: 1.6;
      margin: 0;
      padding: 0;
      background-color: #f7fdf7;
    }

    .navbar {
      position: sticky;
      top: 0;
      background-color: #2e8b57;
      padding: 10px 0;
      text-align: center;
      box-shadow: 0 2px 6px rgba(0,0,0,0.1);
      z-index: 1000;
    }

    .navbar ul {
      list-style: none;
      display: flex;
      justify-content: center;
      gap: 30px;
      margin: 0;
      padding: 0;
    }

    .navbar a {
      color: white;
      text-decoration: none;
      font-weight: bold;
      font-size: 1.1em;
    }

    .navbar a:hover {
      color: #cce5cc;
    }

    .about-container {
      max-width: 800px;
      margin: 40px auto;
      padding: 20px;
      background: #ffffff;
      border-radius: 12px;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
    }

    .about-container h1 {
      color: #2e8b57;
      text-align: center;
    }

    .about-container p {
      margin-bottom: 1em;
    }

    .footer {
      text-align: center;
      margin-top: 50px;
      font-size: 0.9em;
      color: #888;
    }
  </style>
</head>
<body>
<nav class="navbar">
  <ul>
    <li><a href="index.php">🏠 Home</a></li>
    <li><a href="budget.php">💰 Budget Tracker</a></li>
    <li><a href="tips.php">📋 Saving Tips</a></li>
    <li><a href="about.php">ℹ️ About</a></li>
    <li><a href="logout.php">🚪 Logout</a></li>
  </ul>
</nav>
<!-- Hero Section -->
    <section class="hero">
        <div class="hero-content">
        </div>
    </section> 

<div class="about-container">
  <h1>About Us</h1>
  <p><strong>Welcome, <?php echo $_SESSION['username']; ?>!</strong></p>

  <p>
    This budgeting app was created to help college students like you better understand, manage, and improve their financial health.
    Managing money as a student is tough — tuition, books, food, and life all add up fast.
  </p>

  <p>
    Our mission is to simplify money management for students. Whether you’re tracking your spending, finding savings tips, or exploring student discounts,
    this tool is designed with your needs in mind.
  </p>

  <p>
    Features include:
    <ul>
      <li>🧾 Easy-to-use budget tracker</li>
      <li>💡 Practical saving tips tailored for student life</li>
      <li>🤖 A financial chatbot (coming soon!)</li>
      <li>🔗 Helpful links to student discounts and resources</li>
    </ul>
  </p>

  <p>
    This site was built using PHP, HTML, and CSS, and is part of an effort to make personal finance more approachable for young adults.
  </p>

  <p><em>“Small savings today lead to big wins tomorrow.”</em></p>
</div>

<div class="footer">
  &copy; <?php echo date('Y'); ?> Student Budgeting Assistant
</div>

</body>
</html>
