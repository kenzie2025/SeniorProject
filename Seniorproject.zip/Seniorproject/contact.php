<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Contact Us</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f2fff2;
      margin: 0;
      padding: 0;
    }

    .navbar {
      position: sticky;
      top: 0;
      background-color: #2e8b57;
      padding: 10px 0;
      text-align: center;
      box-shadow: 0 2px 6px rgba(0,0,0,0.1);
      z-index: 1000;
    }

    .navbar ul {
      list-style: none;
      display: flex;
      justify-content: center;
      gap: 30px;
      margin: 0;
      padding: 0;
    }

    .navbar a {
      color: white;
      text-decoration: none;
      font-weight: bold;
      font-size: 1.1em;
    }

    .navbar a:hover {
      color: #cce5cc;
    }

    .contact-container {
      max-width: 600px;
      margin: 40px auto;
      background: white;
      padding: 30px;
      border-radius: 12px;
      box-shadow: 0 2px 10px rgba(0,0,0,0.05);
    }

    .contact-container h1 {
      text-align: center;
      color: #2e8b57;
    }

    form label {
      display: block;
      margin-top: 15px;
    }

    input, textarea {
      width: 100%;
      padding: 10px;
      margin-top: 5px;
      border-radius: 6px;
      border: 1px solid #ccc;
      font-size: 1em;
    }

    button {
      margin-top: 20px;
      background-color: #2e8b57;
      color: white;
      border: none;
      padding: 12px 20px;
      border-radius: 6px;
      cursor: pointer;
      font-size: 1em;
    }

    button:hover {
      background-color: #246b45;
    }
  </style>
</head>
<body>

<nav class="navbar">
  <ul>
    <li><a href="index.php">🏠 Home</a></li>
    <li><a href="budget.php">💰 Budget Tracker</a></li>
    <li><a href="tips.php">📋 Saving Tips</a></li>
    <li><a href="about.php">ℹ️ About</a></li>
    <li><a href="contact.php">✉️ Contact</a></li>
    <li><a href="logout.php">🚪 Logout</a></li>
  </ul>
</nav>

<div class="contact-container">
  <h1>Contact Us</h1>
  <p>Have questions, suggestions, or feedback? We'd love to hear from you!</p>

  <form action="submitcontact.php" method="POST">
    <input type="text" name="name" placeholder="Your Name" required>
    <input type="email" name="email" placeholder="Your Email" required>
    <textarea name="message" placeholder="Your Message" required></textarea>
    <button type="submit">Submit</button>
</form>
</div>

</body>
</html>
