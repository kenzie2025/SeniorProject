<?php
session_start();
include('db.php');

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$title = trim($_POST['title']);
$goalAmount = floatval($_POST['goal_amount']);
$userId = $_SESSION['user_id'];

// Insert new goal into database
$stmt = $conn->prepare("INSERT INTO savings_goals (user_id, title, goal_amount) VALUES (?, ?, ?)");
$stmt->bind_param("isd", $userId, $title, $goalAmount);
$stmt->execute();
$stmt->close();

header("Location: budget.php");
exit();
